-- Select Display & Draw Frames
ez.SetDispFrame(0)
ez.SetDrawFrame(0)
-- Fill screen with navy color
ez.Cls(ez.RGB(0, 0, 128))
-- Select True Type font no 6, height = 64 pixels, Width = Automatic
ez.SetFtFont(6, 64, 0)
-- Set golden color for drawing
ez.SetColor(ez.RGB(255, 215, 0))
-- Set screen position for drawing
ez.SetXY(10, 10)
-- Print Hello World !
print("Hello World !")

